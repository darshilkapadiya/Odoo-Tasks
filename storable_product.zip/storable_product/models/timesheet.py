# -*- coding: utf-8 -*-

from odoo import models, fields, api


class AnalyticLine(models.Model):
    _inherit = 'account.analytic.line'

    @api.model
    def create(self, vals):
        analytic_line = super(AnalyticLine, self).create(vals)
        if analytic_line.project_id:
            print("@@@@@@@@@@@@@@@@@@@@",analytic_line)
            sale_order = analytic_line.project_id.sale_order_id
            sale_order_line = sale_order.order_line.filtered(lambda l: l.product_template_id == analytic_line.project_id)
            print("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$",sale_order_line)
            # Calculate timesheet cost and add it to the sale order line
            if sale_order_line:
                timesheet_cost = analytic_line.unit_amount * analytic_line.product_id.standard_price
                sale_order_line.write({
                    'price_subtotal': sale_order_line.price_subtotal + timesheet_cost
                })
                print("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$",sale_order_line)
        return analytic_line
