# -*- coding: utf-8 -*-

from odoo import models, fields

class ProductTemplate(models.Model):
    _inherit = 'product.template'

    is_project_creation_enabled = fields.Boolean(string="Create Project", help="Enable project creation for this storable product")
