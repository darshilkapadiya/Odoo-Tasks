# -*- coding: utf-8 -*-

from odoo import models, fields, api


class SaleOrder(models.Model):
    _inherit = 'sale.order'

    def action_confirm(self):
        res = super(SaleOrder, self).action_confirm()
        for order in self:
            for line in order.order_line:
                product = line.product_id
                if product.is_project_creation_enabled:
                    # Create related project for the storable product
                    project = self.env['project.project'].create({
                        'name': f"{order.name} - {product.name}",
                        'partner_id':order.partner_id.id,
                        'sale_order_id': order.id,
                    })
                    print("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!",order.id)
                    project_task = self.env['project.task'].create({
                        'name':f"{project.name} - {product.name}",
                        'project_id':project.id,
                        'partner_id':order.partner_id.id,
                        'sale_line_id':order.id,
                    })
                    print("########################################################################################",project_task.sale_order_id)
                    # Link project to the sale order line
                    line.write({'project_id': project.id})
        return res
