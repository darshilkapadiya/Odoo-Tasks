# -*- coding: utf-8 -*-
# from odoo import http


# class StorableProduct(http.Controller):
#     @http.route('/storable_product/storable_product', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/storable_product/storable_product/objects', auth='public')
#     def list(self, **kw):
#         return http.request.render('storable_product.listing', {
#             'root': '/storable_product/storable_product',
#             'objects': http.request.env['storable_product.storable_product'].search([]),
#         })

#     @http.route('/storable_product/storable_product/objects/<model("storable_product.storable_product"):obj>', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('storable_product.object', {
#             'object': obj
#         })
