# -*- coding: utf-8 -*-

from odoo import api,models, fields

class StudentInfo(models.Model):
    _name = 'student.student'
    _description = 'Student Information'

    name = fields.Char(string='Student Name', required=True)
    birth_date = fields.Date(string='Date of Birth')
    gender = fields.Selection([('male', 'Male'), ('female', 'Female')], string='Gender')
    phone = fields.Char(string='Phone')
    email = fields.Char(string='Email')
    address = fields.Text(string='Address')
    partner_id = fields.Many2one('res.partner', string='Related Partner', ondelete='cascade')
    invoice_ids = fields.One2many('account.move', 'student_id', string="Invoices")
    invoice_count = fields.Integer(compute='_compute_invoice_count', string="Invoices")


    def admission_report(self):
        return {
            'name': 'Generate Admission Report',
            'type': 'ir.actions.act_window',
            'target': 'new',
            'res_model': 'admission.report.wizard',
            'view_mode': 'form',
            'views': [[False, 'form']],
            'context':self.ids
        }

    def action_view_invoices(self):
        self.ensure_one()
        return {
            'type': 'ir.actions.act_window',
            'name': 'Invoices',
            'view_mode': 'tree,form',
            'res_model': 'account.move',
            'domain': [('partner_id', '=', self.partner_id.id)],
            'context': dict(self.env.context),
        }

    def _compute_invoice_count(self):
        for student in self:
            student.invoice_count = self.env['account.move'].search_count([('partner_id', '=', student.partner_id.id)])

    @api.model
    def create(self, vals):
        partner_vals = {
            'name': vals.get('name'),
            'phone': vals.get('phone'),
            'email': vals.get('email'),
            'type': 'contact',
            'street':vals.get('address'),
            'company_id': self.env.user.company_id.id,
        }
        partner = self.env['res.partner'].create(partner_vals)
        vals['partner_id'] = partner.id
        return super(StudentInfo, self).create(vals)

    def write(self, vals):
        res = super(StudentInfo, self).write(vals)
        for student in self:
            if student.partner_id:
                partner_vals = {
                    'name': student.name,
                    'phone': student.phone,
                    'email': student.email,
                    'street':student.address
                }
                student.partner_id.write(partner_vals)
        return res

    def action_print_id_card(self):
        return self.env.ref('student_management.action_report_student_id_card').report_action(self)
