# -*- coding: utf-8 -*-

from odoo import api,models, fields


class AccountMove(models.Model):
    _inherit = 'account.move'

    student_id = fields.Many2one('student.student', string='Student')
