# -*- coding: utf-8 -*-

from odoo import api,models, fields
import logging
_logger = logging.getLogger(__name__)


class AdmissionReportWizard(models.TransientModel):
    _name = 'admission.report.wizard'

    date_from = fields.Date('Start Date')
    date_to = fields.Date('End Date')
    report_type = fields.Selection([
        ('month', 'Month-wise'),
        ('quarter', 'Quarter-wise'),
        ('year', 'Year-wise'),
        ('custom', 'Custom Date')
    ], default='custom', string="Report Type")

    def action_print_report(self):
        student_ids = self.env.context.get('active_ids')
        student_records = self.env['student.student'].browse(student_ids)
        data = []
        data = {}
        name_l = []
        date_l = []
        for sr in student_records:
            name_l.append(sr.name)
            date_l.append(sr.birth_date)
            data['name'] = name_l
            data['birthdate'] = date_l

        return self.env.ref('student_management.admission_report_wizard').report_action(self,data={'data':student_records})
